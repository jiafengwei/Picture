../mmdetection/tools/dist_train.sh cfg_retinanet_ghm_r50_fpn_1x.py 8
