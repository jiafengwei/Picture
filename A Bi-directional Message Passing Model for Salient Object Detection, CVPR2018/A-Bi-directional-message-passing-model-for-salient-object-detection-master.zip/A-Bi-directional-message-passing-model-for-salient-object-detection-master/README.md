# A Bi-directional Mssage Passing Model for Salient Object Detection
## Introduction
This package contains the source code for [A Bi-directional Mssage Passing Model for Salient Object Detection](https://drive.google.com/file/d/1sD2hXJpnOJqCOn2MA1L7kVwop7tSdhMD/view?usp=sharing), CVPR 2018. This code is tested on Tensorflow 1.2.1 Ubuntu14.04.
## Usage Instructions
* Instill these requirements if necessary: Python 2.7, Tensorflow 1.2.1, Numpy, Opencv.
* Put your test images in the `./data` directory.
* Download the pretrained model from [here](https://pan.baidu.com/s/1Onc6-wVeL8g8qg-LYG6elw), and put it under the `./model` directory.
* Run `TestingModel.py` to generate saliency map.
## Citation
If you find our work useful in your research, please consider to cite our paper:

       @inproceedings{Zhang2018,
              author = {Zhang, Lu and Dai, Ju and Lu, Huchuan and He, You and Wang, Gang},
              title = {A Bi-directional Message Passing Model for Salient Object Detection},
              booktitle = {The IEEE Conference on Computer Vision and Pattern Recognition (CVPR)},
              year = {2018}}
